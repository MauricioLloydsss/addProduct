package com.example.buyproducts;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ViewHolder;
import com.squareup.picasso.Picasso;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {
    private List<Product> productList;

    public ProductAdapter(List<Product> productList) {
        this.productList = productList;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.productadapter, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product product = productList.get(position);
        holder.productNameTextView.setText(product.getName());
        holder.productIdTextView.setText(product.getId());
        holder.productPriceEditText.setText(product.getPrice());

        // Load and display the image using Picasso
        if (product.getImageUrl() != null && !product.getImageUrl().isEmpty()) {
            Picasso.get().load(product.getImageUrl()).placeholder(R.drawable.placeholder).into(holder.productImageView);
        }

        // Set an OnClickListener for the Add to Cart button
        holder.addToCartBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final DialogPlus dialogPlus = DialogPlus.newDialog(holder.productImageView.getContext())
                        .setContentHolder(new ViewHolder(R.layout.addtocart_popup))
                        .setExpanded(true, 1200)
                        .create();

                View view = dialogPlus.getHolderView();
                EditText productIDEditText = view.findViewById(R.id.productIDEditText);
                EditText productNameEditText = view.findViewById(R.id.productNameEditText);
                EditText productQuantity = view.findViewById(R.id.productQuantityEditText);
                Button btnAddCart = view.findViewById(R.id.btnAddCart);

                // Initialize the EditText fields with model values
                productIDEditText.setText(product.getId());
                productNameEditText.setText(product.getName());

                dialogPlus.show();
                btnAddCart.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Get the quantity entered by the user
                        int quantity = Integer.parseInt(productQuantity.getText().toString());

                        // Create a Cart object with the selected product's details and quantity
                        Cart cartItem = new Cart(product.getId(), product.getName(), product.getPrice(), quantity);

                        // Save the cart item in the "cart" database
                        saveCartItemToCartDatabase(cartItem);

                        // Close the dialog after adding to the cart
                        dialogPlus.dismiss();
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    static class ProductViewHolder extends RecyclerView.ViewHolder {
        TextView productNameTextView;
        TextView productIdTextView;
        TextView productPriceEditText;
        ImageView productImageView;
        Button addToCartBTN;

        ProductViewHolder(View itemView) {
            super(itemView);
            productNameTextView = itemView.findViewById(R.id.productNameTextView);
            productIdTextView = itemView.findViewById(R.id.productIdTextView);
            productPriceEditText = itemView.findViewById(R.id.productPriceEditText);
            productImageView = itemView.findViewById(R.id.productImageView);
            addToCartBTN = itemView.findViewById(R.id.addToCartBTN); // Initialize the Edit button
        }
    }

    // Function to save a Cart item to the "cart" database
    private void saveCartItemToCartDatabase(Cart cartItem) {
        // Initialize Firebase Database
        FirebaseDatabase database = FirebaseDatabase.getInstance();

        // Reference to the "cart" node in your Firebase Realtime Database
        DatabaseReference cartRef = database.getReference("cart");

        // Push a new child node to generate a unique key for the cart item
        DatabaseReference newCartItemRef = cartRef.push();

        // Set the value of the new cart item using the Cart object
        newCartItemRef.setValue(cartItem)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // Item added to the cart successfully
                        // You can add a callback or show a toast message here to confirm the addition
                        Log.d("CartDatabase", "Item added to cart successfully");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        // Handle the failure to add the item to the cart
                        // You can add an error message or log the error for debugging
                        Log.e("CartDatabase", "Failed to add item to cart: " + e.getMessage());
                    }
                });
    }
}
